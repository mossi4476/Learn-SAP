sap.ui.define(["sap/fe/AppComponent"], ac =>
  ac.extend("studentsDetails.Component", {
    metadata: { manifest: "json" }
  })
);